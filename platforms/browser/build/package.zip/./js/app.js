$(window).on('load', function() { 
  // add delay to show loading image
  setTimeout(
    function() 
    {
      $('#loading').hide();
    }, 1000);

 
 });